public class  Conversions {
    // convert feet to meters
    public static double footToMeter(double foot) {
        return 0.305 * foot;
    }

    //concert meters to feet
    public static double meterToFoot(double meter) {
        return 3.279 * meter;
    }

    public static void main(String[] args) {

        //create header
        System.out.printf("%-10s %-10s | %-10s %-10s\n", "Feet", "Meters", "Meters", "Feet");
        System.out.println("---------------------------------------------");

        //loop to 10, as there are 10 numbers that need to be printed
        for (int i = 1; i <=10; i++) {

        // convert meters to feet, and feet to meters
            double meters = footToMeter(i);
            double feet = meterToFoot(i*5+15);

        //print the first two numbers, and an "|", then the other 2. spaced out. add 15 because the meters conversions start at 20.
            System.out.printf("%-10.1f %-10.3f | %-10.1f %-10.3f\n", (double) i, meters, (double) (i * 5 + 15), feet);
        }
    }
}